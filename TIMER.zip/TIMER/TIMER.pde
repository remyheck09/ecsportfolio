// Remy Heckmann | March 26, 2026 | Timer
import processing.sound.*;
SoundFile alarm;
Button btnStart, btnStop, btnReset;

int totalTime = 10;     
int startTime = 0;
int timeLeft = 0;
boolean running = false;

void setup() {
  size(500, 500);
  alarm = new SoundFile(this, "alarm.mp3");

  btnStart = new Button(95, 80, 100, 30, "Start", color(#6BC7D8), color(#326986));
  btnStop  = new Button(250, 80, 100, 30, "Stop",  color(#6BC7D8), color(#326986));
  btnReset = new Button(400, 80, 100, 30, "Reset", color(#6BC7D8), color(#326986));

  timeLeft = totalTime;
}

void draw() {
  background(#D3F0FF);


  if (running == true) {
    int elapsed = (millis() - startTime) / 1000;
    timeLeft = totalTime - elapsed;

    if (timeLeft <= 0) {
      timeLeft = 0;
      running = false;
      alarm.play();   
    }
  }

  // Draw buttons
  btnStart.display();
  btnStart.hover();
  btnStop.display();
  btnStop.hover();
  btnReset.display();
  btnReset.hover();

  // Timer display
  fill(#95CDD6);
  rect(width/2, height/2, width-100, 200);

  fill(#0B0D0D);
  textSize(100);
  textAlign(CENTER, CENTER);
  text(timeLeft, width/2, 238);
}

void mousePressed() {
  if (btnStart.over == true) {
    running = true;
    startTime = millis();
  }

  if (btnStop.over == true) {
    running = false;
  }

  if (btnReset.over == true) {
    running = false;
    timeLeft = totalTime;  
  }
}
